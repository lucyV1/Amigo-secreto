let amigos = [];

function agregarNombre() {
    let nombreInput = document.querySelector('.input-title');
    let nombre = nombreInput.value.trim();

    if (nombre === '') {
        alert('Por favor, ingresa un nombre válido.');
        return;
    }

    if (amigos.length >= 5) {
        alert('Ya has agregado 5 nombres. No puedes agregar más.');
        return;
    }

    amigos.push(nombre);
    nombreInput.value = '';
    actualizarLista();
}

function actualizarLista() {
    let listaAmigos = document.querySelector('ul');
    listaAmigos.innerHTML = '';

    amigos.forEach(function(amigo) {
        let li = document.createElement('li');
        li.textContent = amigo;
        listaAmigos.appendChild(li);
    });
}

function sortearAmigo() {
    if (amigos.length === 0) {
        alert('No hay amigos en la lista para sortear.');
        return;
    }

    let indiceAleatorio = Math.floor(Math.random() * amigos.length);
    let amigoSecreto = amigos[indiceAleatorio];
    let resultado = document.querySelector('.result-list');
    resultado.textContent = `El amigo secreto es: ${amigoSecreto}`;
}

document.querySelector('.button-add').addEventListener('click', agregarNombre);
document.querySelector('.button-draw').addEventListener('click', sortearAmigo);